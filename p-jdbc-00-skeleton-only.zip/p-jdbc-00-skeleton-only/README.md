# Esquelet JDBC Calendar (Events, Employees, Colors)

En aquest repositori teniu un esquelet per a crear i completar un projecte bàsic de JDBC, seguint l'exemple que s'explica als vídeos corresponents.

Addicionalment, hi trobareu l'script SQL per a MySQL.
